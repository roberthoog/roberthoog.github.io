---
layout: page
title: Education
permalink: /edu/
---
My Education so far at Linnaeus Univesity has gone so-so. I tend to get behind in fast-paced courses as I have an 
inherently slow pace. Slow but careful and meticulous in some ways.

